#-----------------------------------------------------Code where all the functionality of knowledge graph is stored---------------------------------
#-----------------------------------------------------Import functions-------------------------------------------------------------------------------
from __future__ import print_function
from py2neo import Graph,Node,Relationship
from neo4jrestclient.client import GraphDatabase
from neo4jrestclient.query import Q
import pandas as pd
from pandas import DataFrame
import csv
import sys
import os
#------------------------------------------------------------------------------------------------------------------------------------------------------
global diseaseLastKey 
global drugLastKey 
global geneLastKey
global pathwayLastKey 
global physiologyLastKey 
global sideeffectLastKey 
global targetLastKey 

global drugDrugLastKey  
global drugPhysiologyLastKey
global drugSideeffectLastKey 
global geneDiseaseLastKey 

#----------------------------------------------------------All defined functions-------------------------------------------------------------------------

#------------------------------For connection setup to neo4 server----------------------------------------------------------------------------------

db = GraphDatabase("http://localhost:7474", username="neo4j", password="saurabhk")

disease = db.labels.create("DISEASE")
drug = db.labels.create("DRUG")
gene = db.labels.create("GENE")
pathway = db.labels.create("PATHWAY")
physiology = db.labels.create("PHYSIOLOGY")
sideeffect = db.labels.create("SIDEEFFECT")
target = db.labels.create("TARGET")

#--------------------------------------------------------------------------------------------------------------------------------------------------------

class knowledgeGraphCreateClass:

#=======================================================================================================================================
    
    #function: To delete all the pre-existing nodes and relationship
    def beginGraph(self):
        print("Deleting all the preexisting nodes and relationship")
        query1 = "MATCH (n) OPTIONAL MATCH (n)-[r]-() DELETE n,r"
        db.query(query1)

#===================================================================================================================================================

    #function to delete all the nodes of the graph
    def delete_all_nodes(self):
        cql = "MATCH (u) DELETE u"
        #cql = "MATCH (n) DETACH DELETE n"
        try:
            db.query(cql)
            print("All the nodes has been deleted")
        except Exception:
            print ("Please run delete_relationships.py before running this script.")

    #Function to delete a single node with relationship attached of a particular label having specific property name and value
    def delete_single_node(self, *argv):
        dataType = str(argv[0]) 
        propertyName = str(argv[1])
        propertyValue = '"'+str(argv[2])+'"'
        q = "MATCH (a:"+dataType+"{"+propertyName+": "+propertyValue+"}) DETACH DELETE a"
        db.query(q)        


#===================================================================================================================================================
 
    #function to delete all the relationships of the graph
    def delete_all_relationships(self):
        cql = "MATCH (u)-[r]->(v) DELETE r"
        db.query(cql)
        print("All the relationships has been deleted")

    #function to delete a specific type of relationship completely
    def delete_complete_relationship(self, *argv):
        dataType1 = str(argv[0]) 
        dataType2 = str(argv[1])
        relationshipType = str(argv[2])
        q = "MATCH (:"+dataType1+")-[r: "+relationshipType+"]-(: "+dataType2+") DELETE r"
        db.query(q)

    #function to delete a relationship between the two nodes
    def delete_single_relationship(self, *argv):
        dataType1 = str(argv[0]) 
        propertyValue1 = '"'+str(argv[1])+'"'
        dataType2 = str(argv[2]) 
        propertyValue2 = '"'+str(argv[3])+'"'
        relationshipType = str(argv[4])
        q = "MATCH (:"+dataType1+" {name : "+propertyValue1+"})-[r:"+relationshipType+"]-(:"+dataType2+" {name: "+propertyValue2+"}) DELETE r"
        db.query(q)

#===================================================================================================================================================

    #function: A basic CSV file loading function
    def loadCSV(self , filename):
        print("Entering to load the given csv file")
        with open(filename, 'r') as csvfile:
            dataframe = pd.read_csv(csvfile, sep='\t', error_bad_lines=False)
            print("loading or reading of file is done")
        csvfile.close()
        return(dataframe)

    #function to append data on the CSV file then returning the index of the data written
    def writeCSV(self, filename, dataa):
        datalist = [dataa]
        with open(filename,'a', newline='') as csvFile:
            writer = csv.writer(csvFile)
            writer.writerow(datalist)
        csvFile.close()
        df = pd.read_csv(filename,  error_bad_lines=False)
        return (df.index[-1])


#===================================================================================================================================================

    #function:we can perform node/entity table location update use in create_node function
    def node_property_add(self,*argv):
    	dataType = str(argv[0]) 
    	propertyName = str(argv[1])
    	propertyValue = '"'+str(argv[2])+'"'
    	query1 = "MATCH (n:"+dataType+") SET n."+propertyName+" += "+propertyValue
    	db.query(query1)
    

    #function to update the name of a particular property
    def update_node_property_name(self,*argv):
    	nodeType = str(argv[0])
    	propertyName = '"'+str(argv[1])+'"'
    	changePropertyName = '"'+str(argv[2])+'"'
    	query1 = "MATCH (n:"+nodeType+") SET n."+propertyName+" = n."+changePropertyName+" REMOVE n."+propertyName+" RETURN 1"
    	db.query(query1)
    
    #function to a update propertyvalue of a property of a node
    def node_property_update(self, *argv):
        nodeType = str(argv[0])
        nodename = '"'+str(argv[1])+'"'
        propertyName = '"'+str(argv[2])+'"'
        propertyValue = '"'+str(argv[3])+'"'
        q = "MATCH (n: "+nodeType+" { name: "+nodename+"}) SET n."+propertyName+" = "+propertyValue+" RETURN n " 
        db.query(q)

    # function to delete a property of a node
    def node_property_delete(self, *argv):
        nodeType = str(argv[0])
        nodename = '"'+str(argv[1])+'"'
        propertyName = '"'+str(argv[2])+'"'
        q = "MATCH (n: "+nodeType+" { name: "+nodename+"}) REMOVE n."+propertyName+" RETURN n " 
        db.query(q)
    
#===================================================================================================================================================
    
    #functiont to update a property value of a property of a relationship
    def relation_property_update(self,*argv):
        nodeType1 = str(argv[0])
        nodeType2 = str(argv[1])
        relationLabel = str(argv[2])
        nodename1 = '"'+str(argv[3])+'"'
        nodename2 = '"'+str(argv[4])+'"'
        propertyType = '"'+str(argv[5])+'"'
        propertyValue = '"'+str(argv[6])+'"'
        q = "Match (d1: "+nodeType1+"{name:"+nodename1+"}),(d2: "+nodeType2+" {name:"+nodename2+"}) Merge (d1)-[r: "+relationLabel+"]->(d2)  ON MATCH SET r."+propertyType+" = r."+propertyValue+" return d1,d2,r"
        db.query(q)


     #functiont to delete a property of a relationship
    def relation_property_delete(self,*argv):
        nodeType1 = str(argv[0])
        nodeType2 = str(argv[1])
        relationLabel = str(argv[2])
        nodename1 = '"'+str(argv[3])+'"'
        nodename2 = '"'+str(argv[4])+'"'
        propertyType = '"'+str(argv[5])+'"'
        q = "Match (d1: "+nodeType1+"{name:"+nodename1+"}),(d2: "+nodeType2+" {name:"+nodename2+"}) Merge (d1)-[r: "+relationLabel+"]->(d2)  REMOVE r."+propertyType+" return d1,d2,r"
        db.query(q)    

#===================================================================================================================================================

    #function to create index on name of every labels
    def create_index(self):
        db.query("CREATE INDEX ON :DISEASE(name)")
        db.query("CREATE INDEX ON :DRUG(name)")
        db.query("CREATE INDEX ON :GENE(name)")
        db.query("CREATE INDEX ON :PATHWAY(name)")
        db.query("CREATE INDEX ON :PHYSIOLOGY(name)")
        db.query("CREATE INDEX ON :SIDEEFFECT(name)")
        db.query("CREATE INDEX ON :TARGET(name)")
     
   
#===================================================================================================================================================
    #function: create the nodes from the tables

    def create_nodes(self,query):
    	db.query(query1)
   
#====================================================================================================================================================
    #function: create the relationships_created

    def create_relations(self,query):
    	db.query(query1)

#=======================================================================================================================================

    def node_schema(self,**kwargs):
                    
        nodeType = kwargs["dataType"]

        if nodeType == "DISEASE":
            print("\nDisease node creation starts")
            df = self.loadCSV('DISEASE_TABLE.csv')
            df.fillna(method='ffill', inplace = True)
            disease = db.labels.create("DISEASE")
            nodes = []
            
            #node creation and add label             
            for index, row in df.iterrows():
                #print(row['DiseaseName'])
                diseaseLastKey = index
                l1 = []
                l1 = disease.get(name = row['DiseaseName'])
                ID = "ds_"+str(index)
                #Check if node has already beeen created
                if(len(l1) == 0):
                    node1 = db.nodes.create(ID = ID, name = row['DiseaseName'])
                    nodes.append(node1)
                    disease.add(node1)   
            print("Disease nodes has been created")

        if nodeType == "DRUG":
            print("\nDrug node creation starts")
            df = self.loadCSV('DRUG_TABLE.csv')
            df.fillna(method='ffill', inplace = True)
            drug = db.labels.create("DRUG")
            nodes = []
            
            #node creation and add label            
            for index, row in df.iterrows():
                #print(row['NAME'])
                drugLastKey = index
                l1 = []
                l1 = drug.get(name = row['NAME'])
                ID = "dr_"+str(index)
                #Check if node has already been created 
                if(len(l1) == 0):
                    node1 = db.nodes.create(ID = ID, name = row['NAME'], state = row['STATE'], group = row['GROUP'], type = row['TYPE'], kingdom = row['KINGDOM'], direct_parent = row['DIRECT_PARENT'], classs = row['CLASS'], superclass = row['SUPERCLASS'], subclass = row['SUBCLASS'] )
                    nodes.append(node1)
                    drug.add(node1)
            print("Drug nodes has been creataed")
            
        if nodeType == "GENE":
            print("\nGene node creation starts")
            df = self.loadCSV('GENE_TABLE.csv')
            df.fillna(method='ffill', inplace = True)
            gene = db.labels.create("GENE")
            nodes = []
            l1 = []
            #node creation and add label             
            for index, row in df.iterrows():
                #print(row['GENE_NAME'])
                geneLastKey = index 
                l1 = []
                l1 = gene.get(name = row['GENE_SYMBOL'])
                ID = "gn_"+str(index)
                #Check if node has already been created 
                if(len(l1) == 0):               
                    node1 = db.nodes.create(ID = ID, name = row['GENE_SYMBOL'], fullname = row['GENE_NAME'], type = row['GENE_TYPE'])
                    nodes.append(node1)
                    gene.add(node1)
            print("Gene nodes has been created")       
            
            
        if nodeType == "PATHWAY":
            print("\nPathway node creation starts")
            df = self.loadCSV('PATHWAY_TABLE.csv')
            df.fillna(method='ffill', inplace = True)
            pathway = db.labels.create("PATHWAY")
            nodes = []
            l1 = []
            #node creation and add label        
            for index, row in df.iterrows():
                #print(row['PATHWAY_NAME'])
                pathwayLastKey = index
                l1 = []
                l1 = pathway.get(name = row['PATHWAY_NAME'])
                ID = "pt_"+str(index)
                #Check if node has already been created or not
                if(len(l1) == 0):
                    node1 = db.nodes.create(ID = ID, name = row['PATHWAY_NAME'], label = row['PATHWAY_LABEL'] )
                    nodes.append(node1)
                    pathway.add(node1)    
            print("Pathway nodes has been created")     
            
            
        if nodeType == "PHYSIOLOGY":
            print("\nPhysiology node creation starts")
            df = self.loadCSV('PHYSIOLOGICAL_TABLE.csv')
            df.fillna(method='ffill', inplace = True)
            physiology = db.labels.create("PHYSIOLOGY")
            nodes = []
            l1 = [] 
            #node creation and add label            
            for index, row in df.iterrows():
                #print(row['LEVEL1'])
                physiologyLastKey = index
                l1 = []
                l1 = physiology.get(name = row['LEVEL1'])
                ID = "ph_"+str(index)
                #Check if node has already been created
                if(len(l1) == 0):
                    node1 = db.nodes.create(ID = ID, name = row['LEVEL1'], code = row['CODE1'] )
                    nodes.append(node1)
                    physiology.add(node1)     
            print("Physiology nodes has been created")            
            
            
        if nodeType == "SIDEEFFECT":
            print("\nSideeffect node creation starts")
            df = self.loadCSV('SIDEEFFECT_TABLE.csv')
            df.fillna(method='ffill', inplace = True)
            sideeffect = db.labels.create("SIDEEFFECT")
            nodes = []

            #node creation and add label             
            for index, row in df.iterrows():
                #print(row['adverse_effect'])
                sideeffectLastKey = index
                l1 = []
                l1 = sideeffect.get(name = row['adverse_effect'])
                ID = "se_"+str(index)
                #Check if node has already been created
                if(len(l1) == 0):
                    node1 = db.nodes.create(ID = ID, name = row['adverse_effect'] )
                    nodes.append(node1)
                    sideeffect.add(node1)     
            print("Sideeffect nodes has been created")            
            
            
        if nodeType == "TARGET":
            print("\nTarget node creation starts")
            df = self.loadCSV('TARGET_TABLE.csv')
            df.fillna(method='ffill', inplace = True)
            target = db.labels.create("TARGET")
            nodes = []
            
            #node creation and add label             
            for index, row in df.iterrows():
                #print(row['TARGET_NAME'])
                targetLastKey = index
                l1 = []
                l1 = target.get(name = row['TARGET_NAME'])
                ID = "tg_"+str(index)
                #Check if node has already been created
                if (len(l1) == 0):
                    node1 = db.nodes.create(ID = ID, name = row['TARGET_NAME'], category = row['CATEGORY'], action = row['ACTION'] )
                    nodes.append(node1)
                    target.add(node1)  
            print("Target nodes has been created")                                                 
            


    	

#=====================================================================================================================================
    def relationship_schema(self,**kwargs):
                    
        nodeType1 = kwargs["relationType1"]
        nodeType2 = kwargs["relationType2"]
                    
                            
        if (nodeType1 == "DRUG" and nodeType2 == "DRUG"):
            print("Drug and Drug relationship")
            df = self.loadCSV('DRUG_DRUG.csv')
            df.fillna(method='ffill', inplace = True)
                    
            for index, row in df.iterrows():
                l1 = []
                l2 = []
                flag1 = 0
                flag2 = 0
                drugDrugLastKey = index
                #check if node1 has already been created, if not created then create one otherwise pass
                l1 = drug.get(name = row['DRUGNAME1'])                                
                if (len(l1) == 0):
                    datalist = row['DRUGNAME1']
                    ID1 = self.writeCSV('newdrug.csv', datalist)
                    ID = "ndr_"+str(ID1)
                    node1 = db.nodes.create(name = row['DRUGNAME1'], ID = ID)
                    drug.add(node1)
                else:
                    node1 = l1[0]
                    flag1 = 1
                                
                #check if node2 has already been created, if not created then create one otherwise pass
                l2 = drug.get(name = row['DRUGNAME2'])
                if (len(l2) == 0):
                    datalist = row['DRUGNAME2']
                    ID1 = self.writeCSV('newdrug.csv', datalist)
                    ID = "ndr_"+str(ID1)
                    node2 = db.nodes.create(name = row['DRUGNAME2'], ID = ID)
                    drug.add(node2)
                else:
                    node2 =  l2[0]
                    flag2 = 1


                #if two nodes are already present check if relationship has already been created, then just update the count value otherwise create relationship
                if (flag1 == 1 and flag2 == 1):            
                    NAME1 = '"'+str(row['DRUGNAME1'])+'"'
                    NAME2 = '"'+str(row['DRUGNAME2'])+'"'
                    modulate = '"'+str(row['MODULATE'])+'"'
                    functionalcomponent = '"'+str(row['FUNCTIONALCOMPONENT'])+'"'
                    q = "Match (d1:DRUG{name:"+NAME1+"}),(d2:DRUG{name:"+NAME2+"}) Merge (d1)-[r: dr_dr]->(d2) ON CREATE SET r.count = 1 ON CREATE SET r.ID = "+str(index)+" ON CREATE SET r.modulate = "+modulate+" ON CREATE SET r.functionalcomponent = "+functionalcomponent+" ON MATCH SET r.count = r.count + 1 return d1,d2,r"
                    db.query(q)

                #create relationship in case one of the nodes were not present earlier
                else:
                    ID = str(index)                       
                    rel1 = node1.relationships.create("dr_dr", node2, ID = ID, modulate = row['MODULATE'], functionalcomponent = row['FUNCTIONALCOMPONENT'], count = 1)
            print("Drug and Drug relationship has been created")

        if (nodeType1 == "DRUG" and nodeType2 == "PHYSIOLOGY"):
            print("\nDrug and Physiology relationship")
            df = self.loadCSV('DRUG_PHYSIOLOGY.csv')
            df.fillna(method='ffill', inplace = True)
            for index, row in df.iterrows():
                l1 = []
                l2 = []
                flag1 = 0
                flag2 = 0
                drugPhysiologyLastKey = index

                #check if node1 has already been created, if not created then create one otherwise pass
                l1 = drug.get(name = row['NAME'])                                
                if (len(l1) == 0):
                    datalist = row['NAME']
                    ID1 = self.writeCSV('newdrug.csv', datalist)
                    ID = "ndr_"+str(ID1)
                    node1 = db.nodes.create(name = row['NAME'], ID = ID)
                    drug.add(node1)
                else:
                    node1 = l1[0]
                    flag1 = 1
                                
                #check if node2 has already been created, if not created then create one otherwise pass
                l2 = physiology.get(name = row['LEVEL1'])
                if (len(l2) == 0):
                    datalist = row['LEVEL1']
                    ID1 = self.writeCSV('newphysiology.csv', datalist)
                    ID = "nph_"+str(ID1)
                    node2 = db.nodes.create(name = row['LEVEL1'], ID = ID)
                    physiology.add(node2)
                else:
                    node2 =  l2[0]
                    flag2 = 1
              
                #if two nodes are already present check if relationship has already been created, then just update the count value otherwise create relationship
                if (flag1 == 1 and flag2 == 1):            
                    NAME1 = '"'+str(row['NAME'])+'"'
                    NAME2 = '"'+str(row['LEVEL1'])+'"'
                    ATC_CODE = '"'+str(row['ATC_CODE'])+'"'
                    q = "Match (d1:DRUG{name:"+NAME1+"}),(d2:PHYSIOLOGY{name:"+NAME2+"}) Merge (d1)-[r: dr_ph]->(d2) ON CREATE SET r.count = 1 ON CREATE SET r.ID = "+str(index)+" ON CREATE SET r.ATC_codelist = "+ATC_CODE+" ON MATCH SET r.count = r.count + 1 return d1,d2,r"
                    db.query(q)
                
                #create relationship in case one of the nodes were not present earlier
                else:
                    ID = str(index)                      
                    rel1 = node1.relationships.create("dr_ph", node2, ID = ID, ATC_codelist = row['ATC_CODE'], count = 1)
            print("Drug and Physiology relationships has been created")    
                    
        if (nodeType1 == "DRUG" and nodeType2 == "SIDEEFFECT"):
            print("\nDrug and sideeffect relationship")
            df = self.loadCSV('DRUG_SIDEEFFECT.csv')
            df.fillna(method='ffill', inplace = True)
            for index, row in df.iterrows():
                l1 = []
                l2 = []
                flag1 = 0
                flag2 = 0
                drugSideeffectLastKey = index

                #check if node1 has already been created, if not created then create one otherwise pass
                l1 = drug.get(name = row['drug_name'])                                
                if (len(l1) == 0):
                    datalist = row['drug_name']
                    ID1 = self.writeCSV('newdrug.csv', datalist)
                    ID = "ndr_"+str(ID1)
                    node1 = db.nodes.create( name = row['drug_name'], ID = ID)
                    drug.add(node1)
                else:
                    node1 = l1[0]
                    flag1 = 1
                                
                #check if node2 has already been created, if not created then create one otherwise pass
                l2 = sideeffect.get( name = row['adverse_effect'])
                if (len(l2) == 0):
                    datalist = row['adverse_effect']
                    ID1 = self.writeCSV('newsideeffect.csv', datalist)
                    ID = "nse_"+str(ID1)
                    node2 = db.nodes.create( name = row['adverse_effect'], ID = ID)
                    sideeffect.add(node2)
                else:
                    node2 =  l2[0]
                    flag2 = 1
            
                #if two nodes are already present check if relationship has already been created, then just update the count value otherwise create relationship
                if (flag1 == 1 and flag2 == 1):            
                    NAME1 = '"'+str(row['drug_name'])+'"'
                    NAME2 = '"'+str(row['adverse_effect'])+'"'
                    q = "Match (d1:DRUG{name:"+NAME1+"}),(d2:SIDEEFFECT{name:"+NAME2+"}) Merge (d1)-[r: dr_se]->(d2) ON CREATE SET r.count = 1 ON CREATE SET r.ID = "+str(index)+" ON MATCH SET r.count = r.count + 1 return d1,d2,r"
                    db.query(q)
                
                #create relationship in case one of the nodes were not present earlier
                else:
                    ID = str(index)                        
                    rel1 = node1.relationships.create("dr_se", node2, ID = ID, count = 1)            
            print("Drug and sideeffect relationship has ben created")    
                            
        if (nodeType1 == "GENE" and nodeType2 == "DISEASE"):
            print("\nGene and Disease relationship")                    
            df = self.loadCSV('GENE_DISEASE.csv')
            df.fillna(method='ffill', inplace = True)
            for index, row in df.iterrows():
                        
                l1 = []
                l2 = []
                flag1 = 0
                flag2 = 0
                geneDiseaseLastKey = index

                #check if node1 has already been created, if not created then create one otherwise pass
                l1 = gene.get(name = row['GeneSymbol'])                                
                if (len(l1) == 0):
                    datalist = row['GeneSymbol']
                    ID1 = self.writeCSV('newgene.csv', datalist)
                    ID = "ngn_"+str(ID1)
                    node1 = db.nodes.create(gene_symbol = row['GeneSymbol'], ID = ID)
                    gene.add(node1)
                else:
                    node1 = l1[0]
                    flag1 = 1
                                
                #check if node2 has already been created, if not created then create one otherwise pass
                l2 = disease.get(name = row['DiseaseName'])
                if (len(l2) == 0):
                    datalist = row['DiseaseName']
                    ID1 = self.writeCSV('newdisease.csv', datalist)
                    ID = "nds_"+str(ID1)
                    node2 = db.nodes.create( name= row['DiseaseName'], ID = ID)
                    disease.add(node2)
                else:
                    node2 =  l2[0]
                    flag2 = 1
        
                #if two nodes are already present check if relationship has already been created, then just update the count value otherwise create relationship
                if (flag1 == 1 and flag2 == 1):            
                    NAME1 = '"'+str(row['GeneSymbol'])+'"'
                    NAME2 = '"'+str(row['DiseaseName'])+'"'
                    q = "Match (d1:GENE{name:"+NAME1+"}),(d2:DISEASE{name:"+NAME2+"}) Merge (d1)-[r: gn_ds]->(d2) ON CREATE SET r.count = 1 ON CREATE SET r.ID = "+str(index)+" ON MATCH SET r.count = r.count + 1 return d1,d2,r"
                    db.query(q)
                
                #create relationship in case one of the nodes were not present earlier
                else:
                    ID = str(index)                        
                    rel1 = node1.relationships.create("gn_ds", node2, ID = ID, count = 1)            
                                        
            print("Gene and Disease relationships has been created")           
                                        
                        

 #========================================================================================================================
'''
 #raw example:

MATCH (u:DRUG {name:'a'}), (r:DRUG {name:'b'})
CREATE (u)-[:DR_DR_interaction {modulate: "increase", count: 0}]->(r)

MATCH (u:DRUG {name:'a'}), (r:DRUG {name:'b'})
MERGE (u)-[p:DR_DR_interaction {modulate: "increase"}]->(r) SET p.count = p.count +1


MATCH  (p:DRUG {name: "a"}), (b:DRUG {name: "b"})
RETURN count( (p)-[:DR_DR_interaction]-(b) )

MATCH  (p:Person {userId: {0}}), (b:Person {userId: {1}}) 
RETURN EXISTS( (p)-[:KNOWS]-(b) )


MATCH (u:DRUG {name:'a'}), (r:DRUG {name:'b'})
MATCH (u)-[p:DR_DR_interaction {modulate: "increase",functionalcomponent: "p"}]->(r)
RETURN count(p)

MATCH (u:DRUG {name:'a'}), (r:DRUG {name:'b'})
MATCH (u)-[p:DR_DR_interaction {modulate: "increase"}]->(r)
RETURN count(p)

MATCH (u:DRUG {name:'a'}), (r:DRUG {name:'b'})
MATCH (u)-[p:DR_DR_interaction {modulate: "increase"}]->(r) SET p.count = p.count +1

MATCH (u:DRUG)-[p:DR_TR_effect ]->(r:TARGET) and MATCH (u:DRUG)-[p:DR_PR_effect ]->(q:PHYSIOLOGY)
'''
