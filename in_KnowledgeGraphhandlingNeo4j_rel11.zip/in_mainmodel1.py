#  in_mainmodel.py should be run for only the first time
#-------------------------------------------------------Import functions------------------------------------------------------------------------------
import os
from neo4jrestclient.client import GraphDatabase
from neo4jrestclient.query import Q
from in_KnowledgeGraphhandlingNeo4j_rel11 import *
import csv
import pandas as pd
from pandas import DataFrame

#from in_location1 import *

db = GraphDatabase("http://localhost:7474", username="neo4j", password="saurabhk")

#---------------------------------------------------------------Variables declared---------------------------------------------------------------------

#------------------------class initialization----------------------------------------------------------------------------------------------------------
kg = knowledgeGraphCreateClass()

#--------------------------Initialise graph for the first time--------------------------------------------------------------------
kg.beginGraph()

#-----------Node creation functions calling----------------------------------------------------------------------------------------------------------------------------------
print("\nNodes creation starts")
kg.node_schema(tableValues="ID, DiseaseName", tableName="DISEASE_TABLE", dataType="DISEASE")
kg.node_schema(tableValues="ID, NAME, STATE, GROUP, TYPE, DIRECT_PARENT, KINGDOM, SUPERCLASS, CLASS, SUBCLASS", tableName="DRUG_TABLE", dataType="DRUG")
kg.node_schema(tableValues="ID, GENE_SYMBOL, GENE_NAME, GENE_TYPE", tableName="GENE_TABLE", dataType="GENE")
kg.node_schema(tableValues="ID, PATHWAY_NAME, PATHWAY_LABEL", tableName="PATHWAY_TABLE", dataType="PATHWAY")
kg.node_schema(tableValues="ID, LEVEL1, CODE1", tableName="PHYSIOLOGICAL_TABLE", dataType="PHYSIOLOGY")
kg.node_schema(tableValues="ID, adverse_effect", tableName="SIDEEFFECT_TABLE", dataType="SIDEEFFECT")
kg.node_schema(tableValues="ID, TARGET_NAME, CATEGORY, ACTION", tableName="TARGET_TABLE", dataType="TARGET")


#------------------------------Index creation calling function------------------------------------------------------------------------------------------
kg.create_index()
#------------------ Relationship creation function calling-----------------------------------------------------------------------------------------------------
print("\nRelationship creation starts")
kg.relationship_schema(tableValues="ID, DRUGNAME1, DRUGNAME2, MODULATE, FUNCTIONALCOMPONENT", relationTableName="DRUG_DRUG", relationType1="DRUG", relationType2="DRUG")
kg.relationship_schema(tableValues="ID, ATC_CODE, NAME, LEVEL1, CODE1", relationTableName="DRUG_PHYSIOLOGY", relationType1="DRUG", relationType2="PHYSIOLOGY")
kg.relationship_schema(tableValues="ID, drug_name, adverse_effect", relationTableName="DRUG_SIDEEFFECT", relationType1="DRUG", relationType2="SIDEEFFECT")
kg.relationship_schema(tableValues="ID, GeneSymbol, DiseaseName", relationTableName="GENE_DISEASE", relationType1="GENE", relationType2="DISEASE")

#kg.relationship_schema(tableValues="ID, ATC_CODE, NAME, LEVEL1, CODE1", relationTableName="DRUG_PHYSIOLOGY", relationType1="DRUG", relationType2="PHYSIOLOGY")
print("\nProgram Completed Successfully")
