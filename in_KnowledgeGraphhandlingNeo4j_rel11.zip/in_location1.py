#All the path that are present here should be changed accordingly


#Change the details accordingly


#Details of neo4j server setup connection
HOST_PORT = "bolt://localhost:7474"
GRAPHUSERNAME = "neo4j"
GRAPHPASSWORD = "saurabhk"


#The path where all the output dictionaries and graph is stored are stored
#OUTPUT_PATH =  

#Store the knowledge graph,dictionary containg entity ,relationship names and the synonym list of each node considered in graph


#Store last index of mysql table for which node are already created
'''DISEASE_LASTID_PATH  
DRUG_LASTID_PATH 
GENE_LASTID_PATH  
PATHWAY_LASTID_PATH 
PHYSIOLOGY_LASTID_PATH 
SIDEEFFECT_LASTID_PATH =
TARGET_LASTID_PATH =



#Store last index of mysql table for which relation are already created
DRUG_DRUG_LASTID_PATH =
DRUG_PHYSIOLOGY_LASTID_PATH = 
DRUG_SIDEEFFECT_LASTID_PATH =
GENE_DISEASE_LASTID_PATH = '''


