from py2neo import Graph, Path, authenticate
import ast,re,json

graph = Graph()

url="http://localhost:7474/db/data/"
authenticate("localhost:7474", "neo4j", "saurabhk")
graph = Graph(url)


def unformated_prop(prop,idval=True):
        prop = prop[1:-1]
        if idval:
                idval,prop = prop.split(',',1)
                idval = idval.split(':',1)[1]
        else:
                idval=0
        prop = re.findall('[\-a-zA-Z0-9_]*:"[\-a-zA-Z0-9_\[\]\(\)/\'\., ]*"|[\-a-zA-Z0-9_]*:[\-a-zA-Z0-9_ ]*',prop)
        new_prop=[]
        for prop in prop:
                x,y = prop.split(':',1)
                new_prop.append('"'+x+'"'+':'+y)
       
        prop = ast.literal_eval('{'+','.join(map(str, new_prop)) +'}')
        return idval,prop

def divide1(symbolString):
    s = []
    val=['','','']
    valind=0
    balanced = True
    index = 0
    symbolString =symbolString[:-1]
    while index < len(symbolString):
        symbol = symbolString[index]
        val[valind]+=symbol
        if symbol == "(" or symbol=='[':
            s.append(symbol)
        elif symbol == ')' or symbol==']':
                s.pop()
                if len(s)==0:
                        valind+=1
        
        index = index + 1
    val[0]=val[0][2:-1]
    val[1]=val[1].split(':',1)[1][:-1]
    val[2]=val[2][4:].strip()
    
    return val

def reljson(reltype):
        typerel = reltype        
        f = open("data_rel.txt","w+")
        for record in graph.cypher.execute("MATCH (n)-[r:"+typerel+"]->(m) RETURN n,r,m LIMIT 25"):
            f.write(str(record[1])+"\n")
            print(record[1])
        f.close()

                                
        file = open("data_rel.txt",'r')
        json_format = { 'results':[ { "columns":["drug", "disease"],"data":[{ "graph":{ "nodes":[],"relationships":[]} }]} ],"errors":[]}
        nodes =[]
        relations = []
        linebreak =1
        for line in file.readlines():
                node1,relat,node2 = divide1(line)
                label1 , prop1 = node1.split(' ',1)
                id1,prop1 = unformated_prop(prop1)
                label2 , prop2 = node2.split(' ',1)
                id2,prop2 = unformated_prop(prop2)
                rellab,relprop = relat.split(' ',1)
                t,relprop = unformated_prop(relprop,False)
                json_format['results'][0]['data'][0]['graph']['nodes'].append({"id":id1,"labels":[label1],"properties":prop1  })
                json_format['results'][0]['data'][0]['graph']['nodes'].append({"id":id2,"labels":[label2],"properties":prop2  })
                json_format['results'][0]['data'][0]['graph']["relationships"].append({ "type":rellab,"startNode": id1,"endNode": id2,"properties":relprop})
                
                linebreak+=1

        #print(json_format['results'][0]['data'][0]['graph']['relationships'])
        y = json.dumps(json_format)

        file1 = open("json_format.json","w")
        file1.write(y)
        file1.close()

reljson("dr_se")                
